var t=async(o)=>{return console.log("Notificaton lambda called!"),{statusCode:200,body:JSON.stringify({ok:!0,event:o})}};export{t as handler};
